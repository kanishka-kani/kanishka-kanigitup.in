<!DOCTYPE html>
<html>
<head>
  <title>Interactive Menu List</title>
  <style>
    ul {
      list-style-type: none;
      padding: 0;
    }
    
    li {
      padding: 10px;
      cursor: pointer;
    }
    
    li:hover {
      background-color: #f0f0f0;
    }
  </style>
</head>
<body>
  <h1>Interactive Menu List</h1>
  
  <ul id="menu-list">
    <li onclick="showContent('home')">Home</li>
    <li onclick="showContent('about')">About</li>
    <li onclick="showContent('services')">Services</li>
    <li onclick="showContent('contact')">Contact</li>
  </ul>
  
  <div id="content">
    <p>Welcome to our website!</p>
  </div>
  
  <script>
    function showContent(page) {
      const contentDiv = document.getElementById('content');
      
      if (page === 'home') {
        contentDiv.innerHTML = '<p>Welcome to our website!</p>';
      } else if (page === 'about') {
        contentDiv.innerHTML = '<p>About Us: We are a company...</p>';
      } else if (page === 'services') {
        contentDiv.innerHTML = '<p>Our Services: We offer...</p>';
      } else if (page === 'contact') {
        contentDiv.innerHTML = '<p>Contact Us: You can reach us at...</p>';
      }
    }
  </script>
</body>
</html>
